@extends('layouts.app')


@section('content')
	


<div class="text-center">
	<h1>Custome 404 page</h1>
</div>

@stop